# List building from a file (CSV / XLSX / Sheets export)

Clients with a filesystem (Claude Code, Cowork) are the preferred path for list building: cleaning happens where the operator can see it, and only validated rows cross the wire.

No filesystem (ChatGPT, web chats)? Same steps: read the rows the operator pasted or attached in the chat yourself, normalise them, and send them in batches. Tool calls cannot receive the attached file, so for more than a few hundred rows ask the operator to upload the CSV in the app's importer instead and follow it with `import_status`.

## 1. Parse and normalise locally
For each row build a lead object with only the keys you have:

| Field | Rule |
|---|---|
| `linkedin_url` / `public_identifier` | Any `linkedin.com/in/<slug>` URL → the server extracts the slug; Sales Navigator (`/sales/lead/…`) and company URLs are **not** identifiers — drop them or find the /in/ URL. Lowercase. |
| `first_name`, `last_name`, `full_name` | Split "Priya Nair" → first/last if only a full name exists; keep `full_name`. Strip titles/emojis. |
| `email_work` (`email` also accepted), `email_personal` | Lowercase, trim; must match `x@y.tld`. Free-mail domains (gmail, yahoo…) belong in `email_personal`. |
| `headline`, `company`, `title`, `location` | Trim; ≤ 300 chars. |
| `custom` | Anything else worth keeping (`{"segment":"fintech","source_row":12}`) — usable in copy as `{{custom.segment}}` and in conditions. |
| `client_id`, `list_id`, `stage_id` | Optional; ids from `workspace_context`. |

A row needs a LinkedIn slug **or** an email; rows with neither are rejected (`E_NO_IDENTIFIER`) — list them for the operator instead of guessing.

## 2. Validate without writing
`lead_upsert(leads, dry_run:true)` in batches of ≤ 500. It returns `valid`, `would_create`, `would_update` (already in the workspace — those rows get enriched, never overwritten) and per-row `errors` `{row_index, code, field, message}`. Fix what you can locally (bad emails, malformed URLs); report the rest.

Tell the operator: total rows, would create, would update, rejected (with reasons), and any obvious duplicates inside the file itself. Wait for approval.

## 3. Write
`lead_upsert(leads, source:"csv:<filename>")` per batch of ≤ 500 (bulk quota: 60 calls/hour ≈ 30,000 leads). Per-row failures do not stop the batch; collect `ids` from each response.

## 4. Organise
- `lead_set_list(lead_ids, list:"<name>", create_if_missing:true)`
- `lead_tag(lead_ids, add:["<campaign tag>"])`
- Optionally `lead_set_stage(lead_ids, stage:"New")`.

## 5. Hand-off
Report: created / updated / failed counts, the list and tag names, and — if a campaign follows — the `leads_search` filter that selects exactly this list (`list_id`) for `enroll_preview`.

## 6. Optional: enrich and blacklist
- `leads_enrich(lead_ids | filters)` (confirmation above 50 leads) queues profile enrichment for leads that are not in a sequence yet. It only spends profile views left over after the day's sequence actions (at most 30% of a sender's allowance, none at warm-up level 0–1), so a big list takes days. Leads that enter a sequence are enriched for free. Skip it unless the copy or the filters need the data before launch.
- A "do not contact" column in the file → `suppressions_add(rows:[{value}], client_id?)` ⚠. Kinds are inferred (email, LinkedIn profile URL, company name or company URL, domain). Scope it to the client when the list belongs to one. Blacklisting never deletes leads or chats.

## When to use the platform importer instead
All gated (`import_create` ⚠); every LinkedIn source runs inside the sender's search / profile-view allowances and working hours, over several days; follow with `import_status(job_id)`.
- A LinkedIn people-search URL → `kind:"search_url", url, sender_id, max_results` (10 or 50 profiles per page).
- People who engaged with a post → `kind:"post_engagement", url:<post URL>, sender_id`. High intent; works for the client's own posts and for competitors' posts.
- Sales Navigator saved search / lead list → `kind:"sn_saved_search" | "sn_lead_list", sender_id, params:{id}`.
- The sender's own connections → `kind:"relations", sender_id`. Existing conversations as leads → `kind:"conversations", sender_id`.
- A CSV already uploaded by the app to the `outreach-imports` bucket → `kind:"csv", storage_path, mapping, row_count`; `mode:"update_only"` + `update_fields` updates chosen columns on matching leads and touches nothing else. For local files prefer `lead_upsert`.
- Repeating imports (daily / weekly / monthly, only new people are added) are set up in the app; `import_schedules_list` shows them. Pair one with `auto_enroll_rules_save` ⚠ so new leads enter a sequence by themselves, inside a daily cap and the usual enrolment checks.
